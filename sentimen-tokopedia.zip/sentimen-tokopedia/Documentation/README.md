# 🎯 SentimentInsight: Analisis Sentimen Pengguna Tokopedia

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://python.org)
[![TensorFlow](https://img.shields.io/badge/TensorFlow-2.13+-orange.svg)](https://tensorflow.org)
[![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3+-green.svg)](https://scikit-learn.org)

Proyek analisis sentimen komprehensif untuk review pengguna aplikasi Tokopedia di Google Play Store menggunakan Machine Learning dan Deep Learning.

## 📋 Deskripsi Project

SentimentInsight adalah sistem analisis sentimen yang mengklasifikasikan review pengguna Tokopedia ke dalam tiga kategori: **Positif**, **Negatif**, dan **Netral**. Project ini mengimplementasikan berbagai algoritma ML/DL dan mencapai akurasi tinggi dalam prediksi sentimen.

### 🎯 Tujuan
- Menganalisis sentimen pengguna terhadap aplikasi Tokopedia
- Membandingkan performa berbagai algoritma ML/DL
- Menyediakan sistem prediksi sentimen yang akurat
- Memenuhi kriteria project dengan standar industri
